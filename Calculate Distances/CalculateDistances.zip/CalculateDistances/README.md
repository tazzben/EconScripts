# Calculate Distances Between Locations #

This is an extremely simple script to calculate geographic distances between cities.  Notes about the code are in the file.

If you don't have mathematica, you can look at the code with CDF Player:

http://www.wolfram.com/products/player/

